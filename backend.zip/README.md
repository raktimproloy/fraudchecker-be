# Fraud Checker Backend API

A robust backend API for the Fraud Checker application built with Express.js, Prisma ORM, and MySQL.

## 🚀 Features

- **Authentication**: JWT-based authentication with Google OAuth integration
- **File Upload**: Secure image upload with Sharp.js optimization
- **Database**: MySQL with Prisma ORM for type-safe database operations
- **Security**: Rate limiting, input validation, CORS protection
- **Admin Panel**: Complete admin management system
- **Multi-language**: Support for English and Bengali content

## 📋 Prerequisites

- Node.js (v16 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

## 🛠️ Installation

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Environment Setup**
   Create a `.env` file in the backend directory:
   ```env
   # Database
   DATABASE_URL="mysql://username:password@localhost:3306/fraud_checker"

   # JWT Secrets
   JWT_ACCESS_SECRET="your-super-secret-access-key-here"
   JWT_REFRESH_SECRET="your-super-secret-refresh-key-here"

   # Google OAuth
   GOOGLE_CLIENT_ID="your-google-client-id"
   GOOGLE_CLIENT_SECRET="your-google-client-secret"

   # Server Configuration
   PORT=5000
   NODE_ENV=development

   # File Upload
   MAX_FILE_SIZE=5242880
   UPLOAD_PATH=./uploads
   ALLOWED_IMAGE_TYPES=image/jpeg,image/png,image/webp

   # Rate Limiting
   RATE_LIMIT_WINDOW_MS=900000
   RATE_LIMIT_MAX_REQUESTS=100

   # CORS
   FRONTEND_URL=http://localhost:3000
   ```

3. **Database Setup**
   ```bash
   # Generate Prisma client
   npm run db:generate

   # Push schema to database
   npm run db:push

   # Seed initial data
   npm run db:seed
   ```

4. **Start Development Server**
   ```bash
   npm run dev
   ```

## 📚 API Endpoints

### Authentication
- `POST /api/auth/google` - Google OAuth login
- `POST /api/auth/refresh` - Refresh JWT tokens
- `POST /api/auth/logout` - User logout
- `POST /api/auth/admin/login` - Admin login
- `POST /api/auth/admin/logout` - Admin logout

### Public Endpoints
- `GET /api/search` - Search fraud records
- `GET /api/stats` - Get site statistics
- `GET /api/language/:lang` - Get language content
- `GET /api/recent-reports` - Get recent approved reports
- `GET /api/report/:id` - Get specific report (public view)

### Protected User Endpoints
- `GET /api/user/profile` - Get user profile
- `POST /api/user/reports` - Submit fraud report
- `POST /api/user/reports/upload` - Upload report images
- `GET /api/user/reports` - Get user's reports
- `GET /api/user/reports/:id` - Get specific report details
- `DELETE /api/user/reports/:id` - Delete pending report

### Admin Endpoints
- `GET /api/admin/dashboard` - Get admin dashboard stats
- `GET /api/admin/users` - Get all users (paginated)
- `PUT /api/admin/users/:id/status` - Update user status
- `GET /api/admin/reports` - Get all reports (with filters)
- `GET /api/admin/reports/pending` - Get pending reports
- `PUT /api/admin/reports/:id/status` - Update report status
- `GET /api/admin/reports/:id` - Get detailed report view
- `POST /api/admin/admins` - Create new admin (super admin only)
- `GET /api/admin/admins` - Get all admins (super admin only)

## 🔐 Default Admin Credentials

After running the seed script:
- **Super Admin**: `superadmin` / `admin123`
- **Moderator**: `moderator` / `moderator123`

## 🗄️ Database Schema

### Core Tables
- **Users**: User accounts with Google OAuth integration
- **Admins**: Admin user accounts with role-based access
- **FraudReports**: Fraud reports submitted by users
- **ReportImages**: Images attached to fraud reports
- **RefreshTokens**: JWT refresh token storage
- **LanguageContent**: Multi-language content support

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Rate Limiting**: API endpoint protection against abuse
- **Input Validation**: Joi-based request validation
- **File Security**: Image type and size validation
- **CORS Protection**: Configured for secure cross-origin requests
- **Password Hashing**: bcrypt for secure password storage

## 📁 Project Structure

```
backend/
├── middleware/
│   ├── auth.js          # Authentication middleware
│   ├── errorHandler.js  # Global error handling
│   ├── upload.js        # File upload with Sharp.js
│   └── validation.js    # Input validation schemas
├── routes/
│   ├── auth.js          # Authentication routes
│   ├── public.js        # Public API routes
│   ├── user.js          # Protected user routes
│   └── admin.js         # Admin routes
├── prisma/
│   ├── schema.prisma    # Database schema
│   └── seed.js          # Database seeding
├── uploads/             # File upload directory
├── server.js            # Main server file
└── package.json         # Dependencies and scripts
```

## 🚀 Deployment

1. **Production Environment Variables**
   - Set `NODE_ENV=production`
   - Use strong JWT secrets
   - Configure production database URL
   - Set up SSL certificates

2. **Database Migration**
   ```bash
   npm run db:migrate
   ```

3. **Start Production Server**
   ```bash
   npm start
   ```

## 🧪 Testing

```bash
# Run tests (when implemented)
npm test
```

## 📝 Scripts

- `npm start` - Start production server
- `npm run dev` - Start development server with nodemon
- `npm run db:generate` - Generate Prisma client
- `npm run db:push` - Push schema to database
- `npm run db:migrate` - Run database migrations
- `npm run db:seed` - Seed initial data

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the ISC License.
#   f r a u d c h e c k e r - f e  
 